import "./map.css";
export const Mymap = () => {
  return (
    <div>
      <iframe className="map"
        src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d41732.51727571891!2d-122.941733!3d49.176229!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xc0cec584cb43103c!2sSandhar%20Trucking%20Ltd!5e0!3m2!1sen!2sca!4v1650351986808!5m2!1sen!2sca"
        referrerpolicy="no-referrer-when-downgrade"
      ></iframe>
    </div>
  );
};
