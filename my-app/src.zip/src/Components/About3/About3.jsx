import "./About3.css";
export const About3 = () => {
  return (
    <div className="abt3-cont">
      <div className="abt3-head">
        <h1>The Sandhar Process</h1>
        <p>
          Our company is approved by The Port of Vancouver to access all major
          ports including Deltaport, Vanterm, Centerm and Fraser Surrey Docks.
          We also provide service to both CN Rail and CP Rail.
        </p>
      </div>
      <div>
        <img
          style={{ width: "100%" , height:"400px" }}
          src="https://media.istockphoto.com/photos/big-ten-wheels-truck-with-container-f-picture-id1355096028?b=1&k=20&m=1355096028&s=170667a&w=0&h=d_JEMsJwwlqFB1KieXLDQepreB2YfA5SeIiI74FbMM8="
          alt=""
        />
      </div>
    </div>
  );
};
